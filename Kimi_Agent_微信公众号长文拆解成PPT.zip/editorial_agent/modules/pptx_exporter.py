"""
PPTX 导出模块
将生成的卡片导出为可编辑的 PowerPoint 文件
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import nsmap
from pptx.oxml import parse_xml
from typing import List, Dict, Tuple, Optional
import os
from PIL import Image as PILImage
import io

from .layout_generator import LayoutConfig, LayoutType, LayoutGenerator


class PPTXExporter:
    """PPTX 导出器"""
    
    # 尺寸映射 (像素到EMU)
    PIXELS_TO_EMU = 12700  # 1像素 = 12700 EMU
    
    # 预设尺寸
    PRESET_SIZES = {
        '1080x1350': (1080, 1350),  # 4:5 Instagram
        '1080x1080': (1080, 1080),  # 1:1 Square
        '1080x1920': (1080, 1920),  # 9:16 Story
        '1200x1500': (1200, 1500),  # 4:5 Large
        '1200x1200': (1200, 1200),  # 1:1 Large
    }
    
    def __init__(self, card_size: Tuple[int, int] = (1080, 1350)):
        """
        初始化PPTX导出器
        
        Args:
            card_size: 卡片尺寸 (宽, 高) 像素
        """
        self.card_width, self.card_height = card_size
        self.layout_generator = LayoutGenerator(card_size)
    
    def export_cards(self, cards: List[Dict], output_path: str, 
                     theme: str = 'editorial') -> str:
        """
        导出卡片为PPTX文件
        
        Args:
            cards: 卡片数据列表
            output_path: 输出文件路径
            theme: 主题名称
            
        Returns:
            输出文件路径
        """
        # 创建演示文稿
        prs = Presentation()
        
        # 设置幻灯片尺寸
        self._set_slide_size(prs)
        
        # 添加每张卡片
        for i, card in enumerate(cards):
            self._add_card_slide(prs, card, i, theme)
        
        # 保存文件
        prs.save(output_path)
        
        return output_path
    
    def _set_slide_size(self, prs: Presentation):
        """设置幻灯片尺寸"""
        # 转换为EMU
        width_emu = self.card_width * self.PIXELS_TO_EMU
        height_emu = self.card_height * self.PIXELS_TO_EMU
        
        prs.slide_width = Emu(width_emu)
        prs.slide_height = Emu(height_emu)
    
    def _add_card_slide(self, prs: Presentation, card: Dict, 
                        index: int, theme: str):
        """添加卡片幻灯片"""
        # 添加空白幻灯片
        blank_layout = prs.slide_layouts[6]  # 空白布局
        slide = prs.slides.add_slide(blank_layout)
        
        # 获取布局配置
        layout = card.get('layout', LayoutGenerator.LAYOUT_PRESETS[LayoutType.FULL_IMAGE_BOTTOM_TEXT])
        
        # 应用主题
        from .layout_generator import StyleManager
        StyleManager.apply_theme_to_layout(layout, theme)
        
        # 计算元素位置
        positions = self.layout_generator.calculate_element_positions(layout)
        
        # 添加背景
        self._add_background(slide, layout)
        
        # 添加图片
        images = card.get('images', [])
        self._add_images_to_slide(slide, positions, images, layout)
        
        # 添加文字
        text_content = {
            'title': card.get('title', ''),
            'body': card.get('content', '')
        }
        self._add_text_to_slide(slide, positions, text_content, layout)
    
    def _add_background(self, slide, layout: LayoutConfig):
        """添加背景"""
        # 添加背景形状
        width_emu = self.card_width * self.PIXELS_TO_EMU
        height_emu = self.card_height * self.PIXELS_TO_EMU
        
        background = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            Emu(0), Emu(0),
            Emu(width_emu),
            Emu(height_emu)
        )
        
        # 设置背景颜色
        background.fill.solid()
        bg_color = self._hex_to_rgb(layout.background_color)
        background.fill.fore_color.rgb = bg_color
        
        # 移除边框
        background.line.fill.background()
    
    def _add_images_to_slide(self, slide, positions: Dict, 
                             images: List[Dict], layout: LayoutConfig):
        """添加图片到幻灯片"""
        if not images:
            return
        
        if layout.layout_type in [LayoutType.TWO_IMAGE_COLLAGE]:
            # 双图布局
            for i, img_key in enumerate(['image1', 'image2']):
                if i < len(images) and img_key in positions:
                    pos = positions[img_key]
                    self._add_single_image(
                        slide, 
                        images[i].get('local_path', ''),
                        pos
                    )
        
        elif layout.layout_type == LayoutType.THREE_IMAGE_GRID:
            # 三图网格
            for i, img_key in enumerate(['image1', 'image2', 'image3']):
                if i < len(images) and img_key in positions:
                    pos = positions[img_key]
                    self._add_single_image(
                        slide,
                        images[i].get('local_path', ''),
                        pos
                    )
        
        elif 'image' in positions:
            # 单图布局
            if images:
                self._add_single_image(
                    slide,
                    images[0].get('local_path', ''),
                    positions['image']
                )
    
    def _add_single_image(self, slide, image_path: str, pos: Dict):
        """添加单张图片"""
        if not image_path or not os.path.exists(image_path):
            return
        
        try:
            # 转换位置为EMU
            left = Emu(pos['x'] * self.PIXELS_TO_EMU)
            top = Emu(pos['y'] * self.PIXELS_TO_EMU)
            width = Emu(pos['width'] * self.PIXELS_TO_EMU)
            height = Emu(pos['height'] * self.PIXELS_TO_EMU)
            
            # 添加图片
            slide.shapes.add_picture(
                image_path,
                left, top,
                width, height
            )
        
        except Exception as e:
            print(f"添加图片失败: {e}")
    
    def _add_text_to_slide(self, slide, positions: Dict, 
                           text_content: Dict, layout: LayoutConfig):
        """添加文字到幻灯片"""
        if 'text' not in positions:
            return
        
        pos = positions['text']
        
        # 转换位置为EMU
        left = Emu(pos['x'] * self.PIXELS_TO_EMU)
        top = Emu(pos['y'] * self.PIXELS_TO_EMU)
        width = Emu(pos['width'] * self.PIXELS_TO_EMU)
        height = Emu(pos['height'] * self.PIXELS_TO_EMU)
        
        # 添加文本框
        textbox = slide.shapes.add_textbox(left, top, width, height)
        text_frame = textbox.text_frame
        text_frame.word_wrap = True
        
        # 添加标题
        title = text_content.get('title', '')
        if title:
            p = text_frame.paragraphs[0]
            p.text = title
            p.font.size = Pt(layout.font_size_title)
            p.font.bold = True
            p.font.color.rgb = self._hex_to_rgb(layout.text_color)
            p.alignment = self._get_alignment(layout.text_align)
            p.space_after = Pt(12)
        
        # 添加正文
        body = text_content.get('body', '')
        if body:
            if title:
                p = text_frame.add_paragraph()
            else:
                p = text_frame.paragraphs[0]
            
            p.text = body
            p.font.size = Pt(layout.font_size_body)
            p.font.color.rgb = self._hex_to_rgb(layout.text_color)
            p.alignment = self._get_alignment(layout.text_align)
            p.line_spacing = layout.line_spacing if hasattr(layout, 'line_spacing') else 1.5
        
        # 如果是叠加文字，添加半透明背景
        if pos.get('overlay'):
            self._add_text_background(slide, pos)
    
    def _add_text_background(self, slide, pos: Dict):
        """添加文字背景（用于叠加文字）"""
        if pos.get('gradient_overlay'):
            # 渐变背景
            left = Emu(pos['x'] * self.PIXELS_TO_EMU)
            top = Emu(pos['y'] * self.PIXELS_TO_EMU)
            width = Emu(pos['width'] * self.PIXELS_TO_EMU)
            height = Emu(pos['height'] * self.PIXELS_TO_EMU)
            
            shape = slide.shapes.add_shape(
                MSO_SHAPE.RECTANGLE,
                left, top, width, height
            )
            
            # 设置半透明黑色渐变
            shape.fill.solid()
            shape.fill.fore_color.rgb = RGBColor(0, 0, 0)
            shape.fill.transparency = 0.5
            shape.line.fill.background()
        
        elif pos.get('text_shadow'):
            # 文字阴影效果（通过添加半透明背景实现）
            left = Emu(pos['x'] * self.PIXELS_TO_EMU)
            top = Emu(pos['y'] * self.PIXELS_TO_EMU)
            width = Emu(pos['width'] * self.PIXELS_TO_EMU)
            height = Emu(pos['height'] * self.PIXELS_TO_EMU)
            
            shape = slide.shapes.add_shape(
                MSO_SHAPE.RECTANGLE,
                left, top, width, height
            )
            
            shape.fill.solid()
            shape.fill.fore_color.rgb = RGBColor(0, 0, 0)
            shape.fill.transparency = 0.4
            shape.line.fill.background()
    
    def _hex_to_rgb(self, hex_color: str) -> RGBColor:
        """将十六进制颜色转换为RGB"""
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return RGBColor(r, g, b)
    
    def _get_alignment(self, align: str):
        """获取文本对齐方式"""
        align_map = {
            'left': PP_ALIGN.LEFT,
            'center': PP_ALIGN.CENTER,
            'right': PP_ALIGN.RIGHT
        }
        return align_map.get(align, PP_ALIGN.LEFT)


class CardDataBuilder:
    """卡片数据构建器"""
    
    def __init__(self, layout_generator: LayoutGenerator, image_matcher):
        self.layout_generator = layout_generator
        self.image_matcher = image_matcher
    
    def build_cards(self, blocks: List[Dict]) -> List[Dict]:
        """
        构建卡片数据
        
        Args:
            blocks: 内容块列表
            
        Returns:
            卡片数据列表
        """
        cards = []
        
        # 生成布局序列
        layouts = self.layout_generator.generate_layout_sequence(len(blocks))
        
        for i, block in enumerate(blocks):
            layout = layouts[i]
            
            # 获取图片
            image_count = layout.image_count
            images = self.image_matcher.find_images_for_block(block, image_count)
            
            # 下载图片
            downloaded_images = []
            for img in images:
                local_path = self.image_matcher.download_image(img)
                if local_path:
                    downloaded_images.append({
                        'url': img.url,
                        'local_path': local_path,
                        'source_type': img.source_type,
                        'source_url': img.source_url
                    })
            
            # 构建卡片
            card = {
                'index': i,
                'title': block.get('title', ''),
                'content': block.get('content', ''),
                'type': block.get('type', 'content'),
                'layout': layout,
                'images': downloaded_images,
                'summary': block.get('summary', '')
            }
            
            cards.append(card)
        
        return cards
