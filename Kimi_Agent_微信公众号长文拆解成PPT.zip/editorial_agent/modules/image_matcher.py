"""
图片匹配与获取模块
支持：原文图片、Instagram图片、互联网搜索图片
"""
import os
import re
import requests
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import hashlib
import time


@dataclass
class ImageSource:
    """图片来源信息"""
    url: str
    source_type: str  # 'original', 'instagram', 'web_search'
    source_url: str
    caption: str = ''
    width: int = 0
    height: int = 0
    relevance_score: float = 0.0


class ImageMatcher:
    """图片匹配器"""
    
    def __init__(self, cache_dir: str = './image_cache'):
        self.cache_dir = cache_dir
        self.original_images = []
        self.instagram_images = []
        self.downloaded_images = set()
        
        os.makedirs(cache_dir, exist_ok=True)
    
    def set_original_images(self, images: List[Dict]):
        """设置原文图片"""
        self.original_images = [
            ImageSource(
                url=img['url'],
                source_type='original',
                source_url=img['url'],
                caption=img.get('caption', ''),
                width=int(img.get('width', 0)) if img.get('width') else 0,
                height=int(img.get('height', 0)) if img.get('height') else 0
            )
            for img in images
        ]
    
    def set_instagram_source(self, instagram_url: str):
        """设置Instagram图片来源"""
        # 这里可以实现Instagram图片抓取
        # 由于Instagram有反爬虫机制，这里提供接口框架
        self.instagram_source = instagram_url
    
    def find_images_for_block(self, block: Dict, count: int = 2) -> List[ImageSource]:
        """
        为内容块寻找合适的图片
        
        Args:
            block: 内容块
            count: 需要的图片数量
            
        Returns:
            图片源列表
        """
        results = []
        search_text = block.get('title', '') + ' ' + block.get('summary', '')
        
        # 1. 优先从原文图片中匹配
        original_matches = self._match_from_original(search_text, count)
        results.extend(original_matches)
        
        # 2. 如果原文图片不足，从Instagram获取
        if len(results) < count and self.instagram_images:
            instagram_matches = self._match_from_instagram(search_text, count - len(results))
            results.extend(instagram_matches)
        
        # 3. 如果还不够，从互联网搜索
        if len(results) < count:
            web_matches = self._search_from_web(search_text, count - len(results))
            results.extend(web_matches)
        
        return results[:count]
    
    def _match_from_original(self, search_text: str, count: int) -> List[ImageSource]:
        """从原文图片中匹配"""
        if not self.original_images:
            return []
        
        # 计算相关性分数
        scored_images = []
        search_keywords = self._extract_keywords(search_text)
        
        for img in self.original_images:
            score = self._calculate_relevance(search_keywords, img.caption)
            scored_images.append((img, score))
        
        # 按分数排序
        scored_images.sort(key=lambda x: x[1], reverse=True)
        
        # 返回前count个
        return [img for img, score in scored_images[:count] if score > 0.1]
    
    def _match_from_instagram(self, search_text: str, count: int) -> List[ImageSource]:
        """从Instagram图片中匹配"""
        # 实现Instagram图片匹配逻辑
        # 这里需要实际的Instagram API或爬虫实现
        return []
    
    def _search_from_web(self, search_text: str, count: int) -> List[ImageSource]:
        """从互联网搜索图片"""
        results = []
        
        # 构建搜索关键词
        keywords = self._build_search_keywords(search_text)
        
        try:
            # 使用图片搜索API
            search_results = self._perform_image_search(keywords, count)
            results.extend(search_results)
        except Exception as e:
            print(f"图片搜索失败: {e}")
        
        return results
    
    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        # 移除标点符号
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # 分词（简单实现，可以使用jieba等分词库）
        words = text.split()
        
        # 过滤停用词和短词
        stopwords = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'}
        
        keywords = [w for w in words if len(w) >= 2 and w not in stopwords]
        
        return keywords
    
    def _calculate_relevance(self, keywords: List[str], caption: str) -> float:
        """计算相关性分数"""
        if not caption:
            return 0.0
        
        caption_lower = caption.lower()
        matches = sum(1 for kw in keywords if kw.lower() in caption_lower)
        
        return matches / max(len(keywords), 1)
    
    def _build_search_keywords(self, search_text: str) -> str:
        """构建图片搜索关键词"""
        # 添加烘焙相关关键词
        baking_keywords = ['烘焙', '面包', '蛋糕', '甜点', 'baking', 'bread', 'cake', 'pastry']
        
        # 提取原文关键词
        original_keywords = self._extract_keywords(search_text)
        
        # 组合关键词
        all_keywords = original_keywords + baking_keywords
        
        # 去重并限制数量
        unique_keywords = list(dict.fromkeys(all_keywords))[:5]
        
        return ' '.join(unique_keywords)
    
    def _perform_image_search(self, keywords: str, count: int) -> List[ImageSource]:
        """执行图片搜索"""
        try:
            from tools.image_search import search_images
            
            images = search_images(keywords, count=count)
            
            return [
                ImageSource(
                    url=img['url'],
                    source_type='web_search',
                    source_url=img.get('source_url', ''),
                    caption=img.get('caption', ''),
                    width=img.get('width', 0),
                    height=img.get('height', 0)
                )
                for img in images
            ]
        except Exception as e:
            print(f"图片搜索失败: {e}")
            return []
    
    def download_image(self, image_source: ImageSource) -> Optional[str]:
        """
        下载图片到本地缓存
        
        Args:
            image_source: 图片来源
            
        Returns:
            本地文件路径或None
        """
        if image_source.url in self.downloaded_images:
            # 已下载，返回缓存路径
            cache_path = self._get_cache_path(image_source.url)
            if os.path.exists(cache_path):
                return cache_path
        
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0'
            }
            
            response = requests.get(image_source.url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                cache_path = self._get_cache_path(image_source.url)
                
                with open(cache_path, 'wb') as f:
                    f.write(response.content)
                
                self.downloaded_images.add(image_source.url)
                
                return cache_path
            
        except Exception as e:
            print(f"下载图片失败: {e}")
        
        return None
    
    def _get_cache_path(self, url: str) -> str:
        """获取缓存文件路径"""
        # 使用URL的hash作为文件名
        url_hash = hashlib.md5(url.encode()).hexdigest()
        
        # 尝试从URL获取扩展名
        ext = '.jpg'
        if '.' in url:
            possible_ext = url.split('.')[-1].split('?')[0].lower()
            if possible_ext in ['jpg', 'jpeg', 'png', 'webp', 'gif']:
                ext = f'.{possible_ext}'
        
        return os.path.join(self.cache_dir, f"{url_hash}{ext}")


class InstagramFetcher:
    """Instagram图片获取器"""
    
    def __init__(self):
        self.session = requests.Session()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        }
    
    def fetch_profile_images(self, profile_url: str, limit: int = 20) -> List[Dict]:
        """
        获取Instagram账号图片
        
        Args:
            profile_url: Instagram个人主页链接
            limit: 获取图片数量限制
            
        Returns:
            图片信息列表
        """
        # 注意：Instagram有严格的反爬虫机制
        # 这里提供框架，实际实现可能需要使用Instagram API或第三方服务
        
        images = []
        
        try:
            # 提取用户名
            username = self._extract_username(profile_url)
            
            if not username:
                return images
            
            # 这里可以实现实际的Instagram抓取逻辑
            # 例如使用instaloader库或Instagram Graph API
            
        except Exception as e:
            print(f"获取Instagram图片失败: {e}")
        
        return images
    
    def _extract_username(self, url: str) -> Optional[str]:
        """从URL提取Instagram用户名"""
        patterns = [
            r'instagram\.com/([^/?]+)',
            r'instagram\.com/([^/?]+)/',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                username = match.group(1)
                if username not in ['p', 'reel', 'stories', 'explore']:
                    return username
        
        return None
