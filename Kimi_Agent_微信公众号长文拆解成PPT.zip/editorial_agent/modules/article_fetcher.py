"""
微信公众号文章抓取与解析模块
"""
import re
import json
import requests
from urllib.parse import urlparse, parse_qs
from bs4 import BeautifulSoup
from typing import Dict, List, Optional, Tuple
import html


class WeChatArticleFetcher:
    """微信公众号文章抓取器"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Referer': 'https://mp.weixin.qq.com/'
        }
    
    def extract_url_params(self, url: str) -> Dict[str, str]:
        """从URL中提取参数"""
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        return {k: v[0] for k, v in params.items()}
    
    def fetch_article(self, url: str) -> Dict:
        """
        抓取微信公众号文章内容
        
        Args:
            url: 微信公众号文章链接
            
        Returns:
            包含文章信息的字典
        """
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.encoding = 'utf-8'
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 提取文章标题
            title = self._extract_title(soup)
            
            # 提取作者信息
            author = self._extract_author(soup)
            
            # 提取发布时间
            publish_time = self._extract_publish_time(soup)
            
            # 提取正文内容
            content_html, content_text = self._extract_content(soup)
            
            # 提取原文图片
            original_images = self._extract_images(soup, url)
            
            # 提取小标题结构
            sections = self._extract_sections(soup)
            
            return {
                'title': title,
                'author': author,
                'publish_time': publish_time,
                'content_html': content_html,
                'content_text': content_text,
                'original_images': original_images,
                'sections': sections,
                'source_url': url,
                'success': True
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'title': '',
                'content_text': '',
                'original_images': [],
                'sections': []
            }
    
    def _extract_title(self, soup: BeautifulSoup) -> str:
        """提取文章标题"""
        # 尝试多种标题选择器
        selectors = [
            '#activity_name',
            '.rich_media_title',
            'h1.rich_media_title',
            '#js_article_title',
            'meta[property="og:title"]'
        ]
        
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                if selector.startswith('meta'):
                    return elem.get('content', '').strip()
                return elem.get_text(strip=True)
        
        # 备用方案
        title_tag = soup.find('title')
        if title_tag:
            return title_tag.get_text(strip=True)
        
        return '无标题'
    
    def _extract_author(self, soup: BeautifulSoup) -> str:
        """提取作者信息"""
        selectors = [
            '#js_name',
            '.profile_nickname',
            '.rich_media_meta_nickname',
            'a#js_name'
        ]
        
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                return elem.get_text(strip=True)
        
        return '未知作者'
    
    def _extract_publish_time(self, soup: BeautifulSoup) -> str:
        """提取发布时间"""
        selectors = [
            '#publish_time',
            '.rich_media_meta_text',
            'em#publish_time'
        ]
        
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                return elem.get_text(strip=True)
        
        return ''
    
    def _extract_content(self, soup: BeautifulSoup) -> Tuple[str, str]:
        """提取正文内容"""
        content_selectors = [
            '#js_content',
            '.rich_media_content',
            '#js_article_content'
        ]
        
        content_html = ''
        content_text = ''
        
        for selector in content_selectors:
            elem = soup.select_one(selector)
            if elem:
                content_html = str(elem)
                # 清理文本
                text = elem.get_text(separator='\n', strip=True)
                # 移除多余空行
                text = re.sub(r'\n{3,}', '\n\n', text)
                content_text = text
                break
        
        return content_html, content_text
    
    def _extract_images(self, soup: BeautifulSoup, base_url: str) -> List[Dict]:
        """提取文章中的图片"""
        images = []
        content_selectors = ['#js_content', '.rich_media_content']
        
        for selector in content_selectors:
            content_elem = soup.select_one(selector)
            if content_elem:
                img_tags = content_elem.find_all('img')
                for img in img_tags:
                    img_url = img.get('data-src') or img.get('src', '')
                    if img_url and not img_url.startswith('data:'):
                        # 获取图片说明（alt或相邻文字）
                        caption = img.get('alt', '')
                        if not caption:
                            # 尝试获取相邻文字
                            parent = img.find_parent(['p', 'figure', 'div'])
                            if parent:
                                next_sibling = img.find_next_sibling()
                                if next_sibling:
                                    caption = next_sibling.get_text(strip=True)
                        
                        images.append({
                            'url': img_url,
                            'caption': caption,
                            'width': img.get('data-w', ''),
                            'height': img.get('data-h', '')
                        })
                break
        
        return images
    
    def _extract_sections(self, soup: BeautifulSoup) -> List[Dict]:
        """提取文章的小标题结构"""
        sections = []
        content_selectors = ['#js_content', '.rich_media_content']
        
        for selector in content_selectors:
            content_elem = soup.select_one(selector)
            if content_elem:
                # 查找所有标题标签
                headings = content_elem.find_all(['h1', 'h2', 'h3', 'h4', 'strong', 'b'])
                
                for heading in headings:
                    text = heading.get_text(strip=True)
                    if text and len(text) < 100:  # 过滤掉过长的"标题"
                        sections.append({
                            'level': self._get_heading_level(heading.name),
                            'text': text,
                            'tag': heading.name
                        })
                
                break
        
        return sections
    
    def _get_heading_level(self, tag_name: str) -> int:
        """获取标题级别"""
        if tag_name in ['h1', 'h2']:
            return 1
        elif tag_name in ['h3', 'h4']:
            return 2
        else:
            return 3


class ArticleParser:
    """文章解析器 - 将文章拆解为信息块"""
    
    def __init__(self, article_data: Dict):
        self.article_data = article_data
        self.content_blocks = []
    
    def parse_to_blocks(self, target_card_count: int = 13) -> List[Dict]:
        """
        将文章解析为内容块
        
        Args:
            target_card_count: 目标卡片数量
            
        Returns:
            内容块列表
        """
        if not self.article_data.get('success', False):
            return []
        
        content_text = self.article_data.get('content_text', '')
        sections = self.article_data.get('sections', [])
        
        # 如果没有明确的小标题，尝试按段落分割
        if not sections:
            return self._parse_by_paragraphs(content_text, target_card_count)
        
        # 按小标题分割内容
        blocks = []
        lines = content_text.split('\n')
        current_block = {
            'title': self.article_data.get('title', ''),
            'content': [],
            'type': 'intro'
        }
        
        section_texts = [s['text'] for s in sections]
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # 检查是否是新的小标题
            is_heading = any(line == st or line in st or st in line for st in section_texts)
            
            if is_heading:
                # 保存当前块
                if current_block['content']:
                    blocks.append(self._finalize_block(current_block))
                
                # 开始新块
                current_block = {
                    'title': line,
                    'content': [],
                    'type': 'section'
                }
            else:
                current_block['content'].append(line)
        
        # 添加最后一个块
        if current_block['content']:
            blocks.append(self._finalize_block(current_block))
        
        # 调整块数量以匹配目标卡片数
        blocks = self._adjust_block_count(blocks, target_card_count)
        
        return blocks
    
    def _parse_by_paragraphs(self, content_text: str, target_card_count: int) -> List[Dict]:
        """按段落分割内容"""
        paragraphs = [p.strip() for p in content_text.split('\n') if p.strip()]
        
        if not paragraphs:
            return []
        
        # 计算每个块应该包含的段落数
        total_paragraphs = len(paragraphs)
        paragraphs_per_block = max(1, total_paragraphs // target_card_count)
        
        blocks = []
        current_block = {
            'title': self.article_data.get('title', '') if not blocks else '',
            'content': [],
            'type': 'content'
        }
        
        for i, para in enumerate(paragraphs):
            # 检测是否是标题（短句、无标点结尾）
            is_title = len(para) < 30 and not para[-1] in '。！？.!?' and i < len(paragraphs) - 1
            
            if is_title and current_block['content']:
                blocks.append(self._finalize_block(current_block))
                current_block = {
                    'title': para,
                    'content': [],
                    'type': 'section'
                }
            else:
                current_block['content'].append(para)
            
            # 达到段落数限制时分割
            if len(current_block['content']) >= paragraphs_per_block and i < len(paragraphs) - 1:
                if current_block['content']:
                    blocks.append(self._finalize_block(current_block))
                    current_block = {
                        'title': '',
                        'content': [],
                        'type': 'content'
                    }
        
        # 添加最后一个块
        if current_block['content']:
            blocks.append(self._finalize_block(current_block))
        
        return self._adjust_block_count(blocks, target_card_count)
    
    def _finalize_block(self, block: Dict) -> Dict:
        """完成内容块的整理"""
        content_text = '\n'.join(block['content'])
        
        # 清理内容
        content_text = re.sub(r'\s+', ' ', content_text)
        content_text = content_text.strip()
        
        # 生成摘要（用于图片搜索）
        summary = content_text[:100] + '...' if len(content_text) > 100 else content_text
        
        return {
            'title': block['title'],
            'content': content_text,
            'type': block['type'],
            'summary': summary,
            'word_count': len(content_text)
        }
    
    def _adjust_block_count(self, blocks: List[Dict], target_count: int) -> List[Dict]:
        """调整块数量以匹配目标卡片数"""
        current_count = len(blocks)
        
        if current_count == target_count:
            return blocks
        
        if current_count < target_count:
            # 需要增加块数 - 将大块拆分
            return self._split_blocks(blocks, target_count)
        else:
            # 需要减少块数 - 合并小块
            return self._merge_blocks(blocks, target_count)
    
    def _split_blocks(self, blocks: List[Dict], target_count: int) -> List[Dict]:
        """将大块拆分为多个小块"""
        result = []
        blocks_needed = target_count - len(blocks)
        
        for block in blocks:
            # 如果内容较长且还需要更多块，则拆分
            if blocks_needed > 0 and len(block['content']) > 150:
                sentences = re.split(r'([。！？.!?])', block['content'])
                sentences = [''.join(sentences[i:i+2]) for i in range(0, len(sentences)-1, 2)]
                
                mid = len(sentences) // 2
                if mid > 0:
                    first_half = ''.join(sentences[:mid]).strip()
                    second_half = ''.join(sentences[mid:]).strip()
                    
                    result.append({
                        'title': block['title'],
                        'content': first_half,
                        'type': block['type'],
                        'summary': first_half[:100] + '...',
                        'word_count': len(first_half)
                    })
                    
                    result.append({
                        'title': '',
                        'content': second_half,
                        'type': 'content',
                        'summary': second_half[:100] + '...',
                        'word_count': len(second_half)
                    })
                    
                    blocks_needed -= 1
                else:
                    result.append(block)
            else:
                result.append(block)
        
        return result
    
    def _merge_blocks(self, blocks: List[Dict], target_count: int) -> List[Dict]:
        """合并小块以减少总数"""
        if len(blocks) <= target_count:
            return blocks
        
        result = []
        merge_ratio = len(blocks) / target_count
        
        i = 0
        while i < len(blocks):
            # 计算应该合并多少个块
            merge_count = max(1, round(merge_ratio))
            merge_count = min(merge_count, len(blocks) - i)
            
            merged_block = blocks[i].copy()
            merged_content = [blocks[i]['content']]
            
            for j in range(1, merge_count):
                merged_content.append(blocks[i + j]['content'])
                if not merged_block['title'] and blocks[i + j]['title']:
                    merged_block['title'] = blocks[i + j]['title']
            
            merged_block['content'] = '\n\n'.join(merged_content)
            merged_block['summary'] = merged_block['content'][:100] + '...'
            merged_block['word_count'] = len(merged_block['content'])
            
            result.append(merged_block)
            i += merge_count
        
        return result[:target_count]
