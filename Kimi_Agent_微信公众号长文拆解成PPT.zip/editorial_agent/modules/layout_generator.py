"""
排版生成模块
生成多种视觉布局的卡片
"""
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import random


class LayoutType(Enum):
    """布局类型"""
    FULL_IMAGE_BOTTOM_TEXT = "full_image_bottom_text"  # 大图配底部文字
    LEFT_IMAGE_RIGHT_TEXT = "left_image_right_text"    # 左图右文
    TOP_TEXT_BOTTOM_IMAGE = "top_text_bottom_image"    # 上文下图
    CENTER_TITLE_MINIMAL = "center_title_minimal"      # 居中标题留白
    TWO_IMAGE_COLLAGE = "two_image_collage"            # 双图拼贴
    HALF_IMAGE_HALF_TEXT = "half_image_half_text"      # 半图半文字
    TEXT_ONLY_MINIMAL = "text_only_minimal"            # 纯文字极简
    OVERLAY_TEXT_ON_IMAGE = "overlay_text_on_image"    # 图片上叠加文字
    THREE_IMAGE_GRID = "three_image_grid"              # 三图网格
    FULL_BLEED_IMAGE = "full_bleed_image"              # 全出血图片


@dataclass
class LayoutConfig:
    """布局配置"""
    layout_type: LayoutType
    image_count: int
    text_position: str  # 'top', 'bottom', 'left', 'right', 'center', 'overlay'
    image_position: str  # 'top', 'bottom', 'left', 'right', 'full', 'grid'
    padding: Tuple[int, int, int, int]  # 上右下左
    font_size_title: int
    font_size_body: int
    text_align: str  # 'left', 'center', 'right'
    background_color: str
    text_color: str
    font_family: str = "Helvetica Neue, Arial, sans-serif"
    line_spacing: float = 1.6
    accent_color: str = "#C9A961"
    
    def copy(self):
        """创建配置的副本"""
        return LayoutConfig(
            layout_type=self.layout_type,
            image_count=self.image_count,
            text_position=self.text_position,
            image_position=self.image_position,
            padding=self.padding,
            font_size_title=self.font_size_title,
            font_size_body=self.font_size_body,
            text_align=self.text_align,
            background_color=self.background_color,
            text_color=self.text_color,
            font_family=self.font_family,
            line_spacing=self.line_spacing,
            accent_color=self.accent_color
        )


class LayoutGenerator:
    """布局生成器"""
    
    # 预设布局配置
    LAYOUT_PRESETS = {
        LayoutType.FULL_IMAGE_BOTTOM_TEXT: LayoutConfig(
            layout_type=LayoutType.FULL_IMAGE_BOTTOM_TEXT,
            image_count=1,
            text_position='bottom',
            image_position='full',
            padding=(40, 40, 40, 40),
            font_size_title=48,
            font_size_body=28,
            text_align='left',
            background_color='#FFFFFF',
            text_color='#333333'
        ),
        LayoutType.LEFT_IMAGE_RIGHT_TEXT: LayoutConfig(
            layout_type=LayoutType.LEFT_IMAGE_RIGHT_TEXT,
            image_count=1,
            text_position='right',
            image_position='left',
            padding=(60, 60, 60, 60),
            font_size_title=42,
            font_size_body=26,
            text_align='left',
            background_color='#FAFAFA',
            text_color='#2C2C2C'
        ),
        LayoutType.TOP_TEXT_BOTTOM_IMAGE: LayoutConfig(
            layout_type=LayoutType.TOP_TEXT_BOTTOM_IMAGE,
            image_count=1,
            text_position='top',
            image_position='bottom',
            padding=(50, 50, 50, 50),
            font_size_title=44,
            font_size_body=26,
            text_align='center',
            background_color='#F5F5F5',
            text_color='#333333'
        ),
        LayoutType.CENTER_TITLE_MINIMAL: LayoutConfig(
            layout_type=LayoutType.CENTER_TITLE_MINIMAL,
            image_count=0,
            text_position='center',
            image_position='none',
            padding=(100, 80, 100, 80),
            font_size_title=56,
            font_size_body=32,
            text_align='center',
            background_color='#FFFFFF',
            text_color='#1A1A1A'
        ),
        LayoutType.TWO_IMAGE_COLLAGE: LayoutConfig(
            layout_type=LayoutType.TWO_IMAGE_COLLAGE,
            image_count=2,
            text_position='bottom',
            image_position='grid',
            padding=(40, 40, 40, 40),
            font_size_title=40,
            font_size_body=24,
            text_align='left',
            background_color='#FFFFFF',
            text_color='#333333'
        ),
        LayoutType.HALF_IMAGE_HALF_TEXT: LayoutConfig(
            layout_type=LayoutType.HALF_IMAGE_HALF_TEXT,
            image_count=1,
            text_position='right',
            image_position='left',
            padding=(0, 0, 0, 0),
            font_size_title=46,
            font_size_body=28,
            text_align='left',
            background_color='#FFFFFF',
            text_color='#2C2C2C'
        ),
        LayoutType.TEXT_ONLY_MINIMAL: LayoutConfig(
            layout_type=LayoutType.TEXT_ONLY_MINIMAL,
            image_count=0,
            text_position='center',
            image_position='none',
            padding=(120, 100, 120, 100),
            font_size_title=52,
            font_size_body=30,
            text_align='center',
            background_color='#F8F8F8',
            text_color='#1A1A1A'
        ),
        LayoutType.OVERLAY_TEXT_ON_IMAGE: LayoutConfig(
            layout_type=LayoutType.OVERLAY_TEXT_ON_IMAGE,
            image_count=1,
            text_position='overlay',
            image_position='full',
            padding=(60, 60, 60, 60),
            font_size_title=54,
            font_size_body=28,
            text_align='center',
            background_color='#000000',
            text_color='#FFFFFF'
        ),
        LayoutType.THREE_IMAGE_GRID: LayoutConfig(
            layout_type=LayoutType.THREE_IMAGE_GRID,
            image_count=3,
            text_position='bottom',
            image_position='grid',
            padding=(40, 40, 40, 40),
            font_size_title=38,
            font_size_body=24,
            text_align='left',
            background_color='#FFFFFF',
            text_color='#333333'
        ),
        LayoutType.FULL_BLEED_IMAGE: LayoutConfig(
            layout_type=LayoutType.FULL_BLEED_IMAGE,
            image_count=1,
            text_position='overlay',
            image_position='full',
            padding=(0, 0, 0, 0),
            font_size_title=60,
            font_size_body=30,
            text_align='center',
            background_color='#000000',
            text_color='#FFFFFF'
        )
    }
    
    def __init__(self, card_size: Tuple[int, int] = (1080, 1350)):
        """
        初始化布局生成器
        
        Args:
            card_size: 卡片尺寸 (宽, 高)，默认 1080x1350 (4:5)
        """
        self.card_width, self.card_height = card_size
        self.layout_sequence = []
        self.current_index = 0
    
    def generate_layout_sequence(self, block_count: int) -> List[LayoutConfig]:
        """
        生成布局序列
        
        Args:
            block_count: 内容块数量
            
        Returns:
            布局配置列表
        """
        layouts = []
        
        # 定义布局轮换模式
        layout_pattern = [
            LayoutType.FULL_IMAGE_BOTTOM_TEXT,      # 第1张：大图底部文字
            LayoutType.CENTER_TITLE_MINIMAL,        # 第2张：居中标题留白
            LayoutType.LEFT_IMAGE_RIGHT_TEXT,       # 第3张：左图右文
            LayoutType.TOP_TEXT_BOTTOM_IMAGE,       # 第4张：上文下图
            LayoutType.TWO_IMAGE_COLLAGE,           # 第5张：双图拼贴
            LayoutType.TEXT_ONLY_MINIMAL,           # 第6张：纯文字极简
            LayoutType.HALF_IMAGE_HALF_TEXT,        # 第7张：半图半文字
            LayoutType.OVERLAY_TEXT_ON_IMAGE,       # 第8张：图片上叠加文字
            LayoutType.FULL_IMAGE_BOTTOM_TEXT,      # 第9张：大图底部文字
            LayoutType.LEFT_IMAGE_RIGHT_TEXT,       # 第10张：左图右文
            LayoutType.THREE_IMAGE_GRID,            # 第11张：三图网格
            LayoutType.CENTER_TITLE_MINIMAL,        # 第12张：居中标题留白
            LayoutType.FULL_BLEED_IMAGE,            # 第13张：全出血图片
        ]
        
        # 根据块数生成布局序列
        for i in range(block_count):
            if i < len(layout_pattern):
                layout_type = layout_pattern[i]
            else:
                # 超出预设模式后循环使用
                layout_type = layout_pattern[i % len(layout_pattern)]
            
            layout = self.LAYOUT_PRESETS[layout_type].copy()
            layouts.append(layout)
        
        self.layout_sequence = layouts
        return layouts
    
    def get_layout_for_block(self, block: Dict, block_index: int) -> LayoutConfig:
        """
        为特定内容块获取布局
        
        Args:
            block: 内容块
            block_index: 块索引
            
        Returns:
            布局配置
        """
        if block_index < len(self.layout_sequence):
            layout = self.layout_sequence[block_index]
        else:
            # 默认布局
            layout = self.LAYOUT_PRESETS[LayoutType.FULL_IMAGE_BOTTOM_TEXT]
        
        # 根据内容调整布局
        layout = self._adjust_layout_for_content(layout, block)
        
        return layout
    
    def _adjust_layout_for_content(self, layout: LayoutConfig, block: Dict) -> LayoutConfig:
        """根据内容调整布局"""
        content = block.get('content', '')
        title = block.get('title', '')
        
        # 如果内容很短，使用更大的字体
        if len(content) < 50:
            layout.font_size_body = int(layout.font_size_body * 1.2)
        
        # 如果内容很长，使用更小的字体
        if len(content) > 300:
            layout.font_size_body = int(layout.font_size_body * 0.85)
        
        # 如果只有标题没有内容，调整为标题专用布局
        if title and not content:
            layout.font_size_title = int(layout.font_size_title * 1.3)
        
        return layout
    
    def calculate_element_positions(self, layout: LayoutConfig) -> Dict:
        """
        计算布局元素的位置和尺寸
        
        Args:
            layout: 布局配置
            
        Returns:
            元素位置信息字典
        """
        positions = {}
        
        padding_top, padding_right, padding_bottom, padding_left = layout.padding
        
        content_width = self.card_width - padding_left - padding_right
        content_height = self.card_height - padding_top - padding_bottom
        
        # 根据布局类型计算位置
        if layout.layout_type == LayoutType.FULL_IMAGE_BOTTOM_TEXT:
            # 图片占70%，文字占30%
            image_height = int(content_height * 0.7)
            text_height = content_height - image_height
            
            positions['image'] = {
                'x': padding_left,
                'y': padding_top,
                'width': content_width,
                'height': image_height
            }
            positions['text'] = {
                'x': padding_left,
                'y': padding_top + image_height,
                'width': content_width,
                'height': text_height
            }
        
        elif layout.layout_type == LayoutType.LEFT_IMAGE_RIGHT_TEXT:
            # 图片占50%，文字占50%
            image_width = content_width // 2
            text_width = content_width - image_width
            
            positions['image'] = {
                'x': padding_left,
                'y': padding_top,
                'width': image_width,
                'height': content_height
            }
            positions['text'] = {
                'x': padding_left + image_width,
                'y': padding_top,
                'width': text_width,
                'height': content_height
            }
        
        elif layout.layout_type == LayoutType.TOP_TEXT_BOTTOM_IMAGE:
            # 文字占30%，图片占70%
            text_height = int(content_height * 0.3)
            image_height = content_height - text_height
            
            positions['text'] = {
                'x': padding_left,
                'y': padding_top,
                'width': content_width,
                'height': text_height
            }
            positions['image'] = {
                'x': padding_left,
                'y': padding_top + text_height,
                'width': content_width,
                'height': image_height
            }
        
        elif layout.layout_type == LayoutType.CENTER_TITLE_MINIMAL:
            # 文字居中
            positions['text'] = {
                'x': padding_left,
                'y': padding_top,
                'width': content_width,
                'height': content_height,
                'centered': True
            }
        
        elif layout.layout_type == LayoutType.TWO_IMAGE_COLLAGE:
            # 两张图片并排，下方文字
            image_height = int(content_height * 0.65)
            text_height = content_height - image_height
            image_width = content_width // 2
            
            positions['image1'] = {
                'x': padding_left,
                'y': padding_top,
                'width': image_width - 10,
                'height': image_height
            }
            positions['image2'] = {
                'x': padding_left + image_width + 10,
                'y': padding_top,
                'width': image_width - 10,
                'height': image_height
            }
            positions['text'] = {
                'x': padding_left,
                'y': padding_top + image_height,
                'width': content_width,
                'height': text_height
            }
        
        elif layout.layout_type == LayoutType.HALF_IMAGE_HALF_TEXT:
            # 半图半文字，无内边距
            half_width = self.card_width // 2
            
            positions['image'] = {
                'x': 0,
                'y': 0,
                'width': half_width,
                'height': self.card_height
            }
            positions['text'] = {
                'x': half_width,
                'y': 0,
                'width': half_width,
                'height': self.card_height
            }
        
        elif layout.layout_type == LayoutType.TEXT_ONLY_MINIMAL:
            # 纯文字居中
            positions['text'] = {
                'x': padding_left,
                'y': padding_top,
                'width': content_width,
                'height': content_height,
                'centered': True
            }
        
        elif layout.layout_type == LayoutType.OVERLAY_TEXT_ON_IMAGE:
            # 图片全屏，文字叠加
            positions['image'] = {
                'x': 0,
                'y': 0,
                'width': self.card_width,
                'height': self.card_height
            }
            positions['text'] = {
                'x': padding_left,
                'y': int(self.card_height * 0.6),
                'width': content_width,
                'height': int(self.card_height * 0.4) - padding_bottom,
                'overlay': True,
                'text_shadow': True
            }
        
        elif layout.layout_type == LayoutType.THREE_IMAGE_GRID:
            # 三图网格，下方文字
            image_height = int(content_height * 0.6)
            text_height = content_height - image_height
            image_width = content_width // 3
            
            for i in range(3):
                positions[f'image{i+1}'] = {
                    'x': padding_left + i * image_width,
                    'y': padding_top,
                    'width': image_width - 10,
                    'height': image_height
                }
            
            positions['text'] = {
                'x': padding_left,
                'y': padding_top + image_height,
                'width': content_width,
                'height': text_height
            }
        
        elif layout.layout_type == LayoutType.FULL_BLEED_IMAGE:
            # 全出血图片，文字叠加在底部
            positions['image'] = {
                'x': 0,
                'y': 0,
                'width': self.card_width,
                'height': self.card_height
            }
            positions['text'] = {
                'x': padding_left,
                'y': int(self.card_height * 0.7),
                'width': content_width,
                'height': int(self.card_height * 0.3) - padding_bottom,
                'overlay': True,
                'gradient_overlay': True
            }
        
        return positions
    
    def apply_style_preferences(self, layout: LayoutConfig, preferences: Dict) -> LayoutConfig:
        """
        应用用户风格偏好
        
        Args:
            layout: 原始布局配置
            preferences: 用户偏好设置
            
        Returns:
            更新后的布局配置
        """
        if 'font_family' in preferences:
            layout.font_family = preferences['font_family']
        
        if 'background_color' in preferences:
            layout.background_color = preferences['background_color']
        
        if 'text_color' in preferences:
            layout.text_color = preferences['text_color']
        
        if 'line_spacing' in preferences:
            layout.line_spacing = preferences['line_spacing']
        
        if 'text_align' in preferences:
            layout.text_align = preferences['text_align']
        
        if 'padding_scale' in preferences:
            scale = preferences['padding_scale']
            layout.padding = tuple(int(p * scale) for p in layout.padding)
        
        return layout


class StyleManager:
    """风格管理器"""
    
    # 预设风格主题
    THEMES = {
        'minimal': {
            'background_color': '#FFFFFF',
            'text_color': '#1A1A1A',
            'accent_color': '#E8E8E8',
            'font_family': 'Helvetica Neue, Arial, sans-serif',
            'line_spacing': 1.6
        },
        'warm': {
            'background_color': '#FDF8F3',
            'text_color': '#4A3728',
            'accent_color': '#D4A574',
            'font_family': 'Georgia, serif',
            'line_spacing': 1.8
        },
        'dark': {
            'background_color': '#1A1A1A',
            'text_color': '#F5F5F5',
            'accent_color': '#333333',
            'font_family': 'Helvetica Neue, Arial, sans-serif',
            'line_spacing': 1.6
        },
        'pastel': {
            'background_color': '#F5F0F5',
            'text_color': '#4A4A4A',
            'accent_color': '#E8D5E8',
            'font_family': 'Helvetica Neue, Arial, sans-serif',
            'line_spacing': 1.7
        },
        'editorial': {
            'background_color': '#FAFAFA',
            'text_color': '#2C2C2C',
            'accent_color': '#C9A961',
            'font_family': 'Times New Roman, serif',
            'line_spacing': 1.8
        }
    }
    
    @classmethod
    def get_theme(cls, theme_name: str) -> Dict:
        """获取预设主题"""
        return cls.THEMES.get(theme_name, cls.THEMES['editorial'])
    
    @classmethod
    def apply_theme_to_layout(cls, layout: LayoutConfig, theme_name: str):
        """将主题应用到布局"""
        theme = cls.get_theme(theme_name)
        
        layout.background_color = theme['background_color']
        layout.text_color = theme['text_color']
        layout.accent_color = theme['accent_color']
        layout.font_family = theme['font_family']
        layout.line_spacing = theme['line_spacing']
