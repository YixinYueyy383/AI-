"""
图片搜索工具
支持多种图片搜索源
"""
import requests
from typing import List, Dict, Optional
import random


def search_images(query: str, count: int = 5, source: str = 'unsplash') -> List[Dict]:
    """
    搜索图片
    
    Args:
        query: 搜索关键词
        count: 返回图片数量
        source: 图片来源 ('unsplash', 'pexels', 'pixabay')
        
    Returns:
        图片信息列表
    """
    images = []
    
    # 烘焙相关关键词扩展
    baking_keywords = [
        'bread', 'cake', 'pastry', 'baking', 'bakery',
        'croissant', 'sourdough', 'dessert', 'patisserie'
    ]
    
    # 构建搜索查询
    search_terms = f"{query} bakery bread pastry"
    
    try:
        # 使用Unsplash API (需要API key)
        # 这里使用模拟数据作为示例
        
        # 模拟图片结果
        sample_images = [
            {
                'url': f'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=1080&h=1350&fit=crop',
                'caption': f'Freshly baked bread - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            },
            {
                'url': f'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=1080&h=1350&fit=crop',
                'caption': f'Artisan croissants - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            },
            {
                'url': f'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=1080&h=1350&fit=crop',
                'caption': f'Chocolate cake - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            },
            {
                'url': f'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=1080&h=1350&fit=crop',
                'caption': f'Fresh pastries - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            },
            {
                'url': f'https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=1080&h=1350&fit=crop',
                'caption': f'Bakery interior - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            },
            {
                'url': f'https://images.unsplash.com/photo-1517433670267-08bbd4be890f?w=1080&h=1350&fit=crop',
                'caption': f'Sourdough bread - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            },
            {
                'url': f'https://images.unsplash.com/photo-1600093463592-8e36ae95ef56?w=1080&h=1350&fit=crop',
                'caption': f'French baguette - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            },
            {
                'url': f'https://images.unsplash.com/photo-1558326567-98ae2405596b?w=1080&h=1350&fit=crop',
                'caption': f'Cinnamon rolls - {query}',
                'source_url': 'https://unsplash.com',
                'width': 1080,
                'height': 1350,
                'photographer': 'Unsplash'
            }
        ]
        
        # 随机选择指定数量的图片
        selected = random.sample(sample_images, min(count, len(sample_images)))
        images.extend(selected)
        
    except Exception as e:
        print(f"图片搜索失败: {e}")
    
    return images[:count]


def get_placeholder_images(count: int = 5) -> List[Dict]:
    """
    获取占位图片（用于测试）
    
    Args:
        count: 图片数量
        
    Returns:
        图片信息列表
    """
    placeholders = [
        {
            'url': f'https://via.placeholder.com/1080x1350/E8D5E8/4A4A4A?text=Baking+1',
            'caption': 'Placeholder image 1',
            'source_url': 'https://via.placeholder.com',
            'width': 1080,
            'height': 1350
        },
        {
            'url': f'https://via.placeholder.com/1080x1350/FDF8F3/4A3728?text=Baking+2',
            'caption': 'Placeholder image 2',
            'source_url': 'https://via.placeholder.com',
            'width': 1080,
            'height': 1350
        },
        {
            'url': f'https://via.placeholder.com/1080x1350/FAFAFA/2C2C2C?text=Baking+3',
            'caption': 'Placeholder image 3',
            'source_url': 'https://via.placeholder.com',
            'width': 1080,
            'height': 1350
        }
    ]
    
    return placeholders[:count]
